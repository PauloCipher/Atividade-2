package com.example.atividade2;

class Navegador {



}
