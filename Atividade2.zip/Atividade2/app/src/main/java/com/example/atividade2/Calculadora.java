package com.example.atividade2;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

class Calculadora {

    EditText num1, num2, result;
    Button btSomar, btSubtrair, btDividir, btMultiplicar;


    double n1, n2, resultado;

    public void onCreate(Bundle savedInstanceState) {


        num1    = (EditText) findViewById(R.calc.num1);
        num2    = (EditText) findViewById(R.calc.num2);
        result  = (EditText) findViewById(R.calc.result);

        btSomar       = (Button)   findViewById(R.botao.btSomar);
        btSubtrair    = (Button)   findViewById(R.botao.btSubtrair);
        btDividir     = (Button)   findViewById(R.botao.btDividir);
        btMultiplicar = (Button)   findViewById(R.botao.btMultiplicar);


        btSomar.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                n1 = Double.parseDouble(num1.getText().toString());
                n2 = Double.parseDouble(num2.getText().toString());

                resultado = n1+n2;


                result.setText(String.valueOf(resultado));
            }
        });


        btSubtrair.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                n1 = Double.parseDouble(num1.getText().toString());
                n2 = Double.parseDouble(num2.getText().toString());

                resultado = n1-n2;


                result.setText(String.valueOf(resultado));
            }
        });


        btDividir.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                n1 = Double.parseDouble(num1.getText().toString());
                n2 = Double.parseDouble(num2.getText().toString());

                resultado = n1/n2;


                result.setText(String.valueOf(resultado));
            }
        });


        btMultiplicar.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                n1 = Double.parseDouble(num1.getText().toString());
                n2 = Double.parseDouble(num2.getText().toString());

                resultado = n1*n2;


                result.setText(String.valueOf(resultado));
            }
        });

    }
}


}
