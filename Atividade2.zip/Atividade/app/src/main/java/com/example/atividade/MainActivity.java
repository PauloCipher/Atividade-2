package com.example.atividade;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText edt_consumo, edt_couvert_artistico, edt_dividir, edt_servico, edt_conta_total, edt_valor_pessoa;

    Button btcalcular;

    double consumo, couvert, dividir, servico, conta, pessoa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        edt_consumo = (EditText) findViewById(R.id.edt_consumo);
        edt_couvert_artistico = (EditText) findViewById(R.id.edt_couvert_artistico);
        edt_dividir = (EditText) findViewById(R.id.edt_dividir);
        edt_servico = (EditText) findViewById(R.id.edt_servico);
        edt_conta_total = (EditText) findViewById(R.id.edt_conta_total);
        edt_valor_pessoa = (EditText) findViewById(R.id.edt_valor_pessoa);

        btcalcular = (Button) findViewById(R.id.bt_calcular);

        btcalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                consumo = Double.parseDouble(edt_consumo.getText().toString());
                couvert = Double.parseDouble(edt_couvert_artistico.getText().toString());
                dividir = Double.parseDouble(edt_dividir.getText().toString());
                servico = Double.parseDouble(edt_servico.getText().toString());
                conta = Double.parseDouble(edt_conta_total.getText().toString());
                pessoa = Double.parseDouble(edt_valor_pessoa.getText().toString());

                conta = consumo + couvert / dividir;

                pessoa = conta / dividir;

                servico = conta * 10 / 100;










            }
        });






    }
}
